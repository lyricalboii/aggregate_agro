# agrotech

# planetoid-vivah
git add .
git commit -m "commit" 
git push


# get latest update
git pull



client id
837007103942-jr4t61mr2h5d007p13sitc7ene3lo0ba.apps.googleusercontent.com

secret id
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

https://aggregate-agro.herokuapp.com/

google credential link
https://console.cloud.google.com/apis/credentials/oauthclient/837007103942-jr4t61mr2h5d007p13sitc7ene3lo0ba.apps.googleusercontent.com?authuser=2&project=agrotech-359105&supportedpurview=project


# infinity free username or password
username = epiz_33441775
password = aggrotech000@