<?php
// $server = "sql301.epizy.com";
// $username = "epiz_33441775";
// $password = "wHtAYbENYKFO";
// $database = "epiz_33441775_XXX";

$server = "localhost";
$username = "root";
$password = "";
$database = "aggrotech";

$con = mysqli_connect($server,$username,$password,$database);


if(!$con){
    die("Database connection error");
}


?>